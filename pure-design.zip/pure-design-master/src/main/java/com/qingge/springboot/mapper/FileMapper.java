package com.qingge.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qingge.springboot.entity.Files;

public interface FileMapper extends BaseMapper<Files> {
}
