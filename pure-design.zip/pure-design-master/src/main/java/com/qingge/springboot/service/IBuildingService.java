package com.qingge.springboot.service;

import com.qingge.springboot.entity.Building;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 青哥哥
 * @since 2022-05-23
 */
public interface IBuildingService extends IService<Building> {

}
